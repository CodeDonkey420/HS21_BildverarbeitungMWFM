﻿#include "operarations.h"
#include <string.h>
#include "utils.h"
#include <math.h>

void dilate(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
  // TODO change to -2 instead of -1
	for (int x = 0; x < MAXXDIM; x++) {
		for (int y = 0; y < MAXYDIM; y++) {
			bool has_neighbor = false;

			if (x != 0) {
				has_neighbor |= in[x - 1][y] == 255;
			}

			if (y != 0) {
				has_neighbor |= in[x][y - 1] == 255;
			}

			if (x != MAXXDIM - 1) {
				has_neighbor |= in[x + 1][y] == 255;
			}

			if (y != MAXYDIM - 1) {
				has_neighbor |= in[x][y + 1] == 255;
			}

			bool is_filled = in[x][y] == 255;
			
			out[x][y] = (has_neighbor || is_filled) * 255;
		}
	}
}

void erode(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
	// reset border pixels
	for (int j = 1; j < MAXXDIM - 1; j++) {
		out[j][0] = 0;
		out[j][MAXYDIM - 1] = 0;
		out[0][j] = 0;
		out[MAXXDIM - 1][j] = 0;
	}
	// reset corners
	out[0][0] = 0;
	out[MAXXDIM - 1][0] = 0;
	out[0][MAXYDIM - 1] = 0;
	out[MAXXDIM - 1][MAXYDIM - 1] = 0;

	for (int x = 1; x < MAXXDIM - 1; x++) {
		for (int y = 1; y < MAXYDIM - 1; y++) {
			bool has_neighbor = in[x - 1][y] == 255 && in[x][y - 1] == 255 && in[x + 1][y] == 255 && in[x][y + 1] == 255 && in[x][y] == 255;

			out[x][y] = has_neighbor * 255;
		}
	}
}

void open_operation(unsigned char in[MAXXDIM][MAXYDIM]) {
	int result;
	int schleifen;
	unsigned char temp[MAXXDIM][MAXYDIM];

	printf("Anzahl an Schleifen?\n"); //Abfrage wie oft die Funktion Öffnen durchgeführt werden soll
	scanf("%d", &schleifen);
	memcpy(temp, in, MAXXDIM * MAXYDIM); //Kopiere nach temp aus image alle Bits die image hat
                                      //
	for (int i = 0; i < schleifen; i++) {
		unsigned char eroded[MAXXDIM][MAXYDIM]; //Speicherpaltz erzeugen
		erode(temp, eroded);
		memcpy(temp, eroded, MAXXDIM * MAXYDIM);
	}
	for (int i = 0; i < schleifen; i++) {
		unsigned char dilated[MAXXDIM][MAXYDIM];
		dilate(temp, dilated);
		memcpy(temp, dilated, MAXXDIM * MAXYDIM);
	}
	result = writeImage_ppm(temp, MAXXDIM, MAXYDIM);
}

void close_operation(unsigned char in[MAXXDIM][MAXYDIM]) {
	int result;
	int schleifen;
	unsigned char temp[MAXXDIM][MAXYDIM];

	printf("Anzahl an Schleifen?\n"); //Abfrage wie oft die Funktion Öffnen durchgeführt werden soll
	scanf("%d", &schleifen);
	memcpy(temp, in, MAXXDIM * MAXYDIM); //Kopiere nach temp aus image alle Bits die image hat

	for (int i = 0; i < schleifen; i++) {
		unsigned char dilated[MAXXDIM][MAXYDIM];
		dilate(temp, dilated);
		memcpy(temp, dilated, MAXXDIM * MAXYDIM);
	}
	for (int i = 0; i < schleifen; i++) {
		unsigned char eroded[MAXXDIM][MAXYDIM];
		erode(temp, eroded);
		memcpy(temp, eroded, MAXXDIM * MAXYDIM);
	}
	result = writeImage_ppm(temp, MAXXDIM, MAXYDIM);
}


int grassfire(unsigned char in[MAXXDIM][MAXYDIM], unsigned char mask[MAXXDIM][MAXYDIM]) {
  reset_matrix(mask);

  int mask_counter = 0;

	for (int x = 0; x < MAXXDIM; x++) {
		for (int y = 0; y < MAXYDIM; y++) {
      if (in[x][y] == 255) {
        grassfire_step(x, y, in, mask);

        mask_counter++;

        // save mask to file
        char	imagedir[128]="C:\\bv\\";
        char	fname[30] = "mask_";
        char  index[3];
        FILE	*fpimage;
        int		i,j;
        int		type=255;

        char	dirbvdir[256]="dir C:\\bv\\*.ppm /B";

        sprintf(index, "%d", mask_counter);
        strcat(fname, index);
        strcat(fname,".ppm");
        strcat(imagedir,fname);

        if ((fpimage = fopen(imagedir,"w+")) == NULL) {
          printf("Kann Datei <%s> nicht oeffnen!\n",imagedir);
          return 1;
        } else {
          fprintf(fpimage,"P3\n");
          fprintf(fpimage,"# Created by IrfanView\n");
          fprintf(fpimage,"%d %d\n",MAXXDIM,MAXYDIM);
          fprintf(fpimage,"%d\n",type);
        
          for (i=0;i<MAXXDIM;i++){
            for (j=0;j<MAXYDIM;j++){
              fprintf(fpimage,"%d %d %d ",mask[i][j], mask[i][j], mask[i][j]);
            }
          }
        }
        fclose(fpimage);

        // AND on input image
        matrix_xor(in, mask);

        // reset mask
        reset_matrix(mask);
      }
    }
  }

  return mask_counter;
}

// nach folie 14
void lin_gwscale(int a1, int ak, unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
  // kennwerte vorher berechnen
  int emin = 255;
  int emax = 0;

  int gws[255];

	for (int x = 0; x < MAXXDIM; x++) {
		for (int y = 0; y < MAXYDIM; y++) {
      int curr = in[x][y];
      if (curr < emin) {
        emin = curr;
      }
      if (curr > emax) {
        emax = curr;
      }
      gws[curr]++;
    }
  }

  float fact = (ak-a1)/(emax-emin);

  for (int x = 0; x < MAXXDIM; x++) {
    for (int y = 0; y < MAXYDIM; y++) {
      out[x][y] = (int) (fact * (in[x][y] - emin)) + a1;
    }
  }
}

void balance_hist (int bucket_size, unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
  pixel_l *curr = (pixel_l*) malloc(sizeof(pixel_l));

  curr = get_gwordered_pixels(in);

  int bucket = 0;
  int buckets = (int) (256 / bucket_size);
  int limit = (int) (256 * 256 / buckets);
  int count = 0;

  while (curr) {
    out[curr->x][curr->y] = bucket * bucket_size;

    count++;

    pixel_l *dead = curr;
    curr = curr->next;
    free(dead);

    if (count >= limit) {
      count = 0;
      bucket++;
    }
  }
}

void sobel(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
	float result;
	int gx;
	int gy;
	//Das Ausgangsbild schwarz machen
	reset_matrix(out);
	for (int x = 1; x < MAXXDIM; x++) {
		for (int y = 1; y < MAXYDIM; y++) {
			// Sobel X
			gx = -in[x - 1][y - 1] - 2 * in[x][y - 1] - in[x + 1][y - 1] + in[x - 1][y + 1] + 2 * in[x][y + 1] + in[x + 1][y + 1];
			// Sobel Y
			gy = -in[x - 1][y - 1] - 2 * in[x - 1][y] - in[x - 1][y + 1] + in[x + 1][y - 1] + 2 * in[x + 1][y] + in[x + 1][y + 1];
			//Gesamt berechnen 
			result = sqrt(gx*gx + gy*gy);

			out[x][y] = result;
		}
	}
}

void laplace(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
	float result;
	int gx;
	int gy;
	//Hintergrund Grau machen
	for (int x = 0; x < MAXXDIM; x++) {
		for (int y = 0; y < MAXYDIM; y++) {
			out[x][y] = 127;
		}
	}
	for (int x = 0; x < MAXXDIM; x++){
		for (int y = 0; y < MAXYDIM; y++)
		{
			result = in[x + 1][y] + in[x][y + 1] + in[x - 1][y] + in[x][y - 1] - 4 * in[x][y];
			if (result > 0)
			{
				out[x][y] = 0; //Schwarz setzen
			}
			if (result < 0)
			{
				out[x][y] = 255; //Weiß setzen
			}
		}

	}
}

void Gauss(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
	reset_matrix(out); //Ausgangsbild schwarz machen
	float result;
	int matrix[3][3] = {
		{1, 2, 1},
		{2, 4, 2},
		{1, 2, 1}
	};
	int matrix_sum = 16;
	//int sum = 0; //Wenn hier def. dann siehe Test Bild test3x31
	// Wenn die Ränder nicht beachtet werden, dann siehe Test Bild test3x3
	for (int x = 1; x < MAXXDIM -1; x++){
		for (int y = 1; y < MAXYDIM -1; y++)
		{
			int sum = 0;
			for (int i = -1; i <= 1; i++)
			{
				for (int z = -1; z <= 1; z++)
				{
					sum += in[x + i][y + z] * matrix[i + 1][z + 1];
				}
			}
			result = sum / matrix_sum;
			out[x][y] = result;
		}
	}
}

void Gaus5x5(unsigned char in[MAXXDIM][MAXYDIM], unsigned  char out[MAXXDIM][MAXYDIM]) {
	reset_matrix(out);
	int matrix[5][5] = {
	{1,  4,  6,  4,  1},
	{4, 16, 24, 16,  4},
	{6, 24, 36, 24,  6},
	{4, 16, 24, 16,  4},
	{1,  4,  6,  4,  1}
	};
	int matrix_sum = 256;
	//int sum = 0;
	float result;
	for (int x = 2; x < MAXXDIM-2; x++)
	{
		for (int y = 2; y < MAXYDIM-2; y++)
		{
			int sum = 0;
			for (int i = -2; i <= 2; i++)
			{
				for (int z = -2; z <= -2; z++)
				{
					sum += in[x + i][y + z] * matrix[i + 2][z + 2];
				}
			}
			result = sum / matrix_sum;
			out[x][y] = result;

		}
	}
}


void Median3x3(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
	reset_matrix(out);
	for (int x = 0; x < MAXXDIM; x++)
	{
		for (int y = 0; y  < MAXYDIM; y ++)
		{
			unsigned char w[9]; //Auf 9 festgelegt, weil 3x3 Matrix
			int k = 0;

			// 3x3 Fenster
			for (int dx = -1; dx <= 1; ++dx) //Nachbar Pixel betrachten
				for (int dy = -1; dy <= 1; ++dy)
					w[k++] = in[x + dx][y + dy];

			// Insertion Sort (für 9 Werte schnell & kompakt)
			for (int i = 1; i < 9; ++i) {
				unsigned char key = w[i];
				int j = i - 1;
				while (j >= 0 && w[j] > key) { w[j + 1] = w[j]; --j; }
				w[j + 1] = key;
			}

			out[x][y] = w[4]; // Median von 9 Werten
		}
	}
}

void Median5x5(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
	reset_matrix(out);
	for (int x = 0; x < MAXXDIM; x++)
	{
		for (int y = 0; y < MAXYDIM; y++)
		{
			unsigned char w[25]; //Auf 25 festgelegt, weil 5x5 Matrix
			int k = 0;

			// 5x5 Fenster
			for (int dx = -1; dx <= 1; ++dx) //Nachbar Pixel betrachten
				for (int dy = -1; dy <= 1; ++dy)
					w[k++] = in[x + dx][y + dy];

			// Insertion Sort (für 9 Werte schnell & kompakt)
			for (int i = 1; i < 25; ++i) {
				unsigned char key = w[i];
				int j = i - 1;
				while (j >= 0 && w[j] > key) { w[j + 1] = w[j]; --j; }
				w[j + 1] = key;
			}

			out[x][y] = w[12]; // Median von 25 Werten hat den Median-Index von 12
		}
	}
}

void DoG(unsigned char in[MAXXDIM][MAXYDIM], unsigned char out[MAXXDIM][MAXYDIM]) {
	//zwei Gauss-Verteilung und dann übereinander legen und die Werte abziehen und dann wir die 2.Ableitung von Gauss erhalten
	// n=6; Maske== 7x7, f=1/64
	const int   b7[7] = { 1, 6, 15, 20, 15, 6, 1 };
	const int   b9[9] = { 1, 8, 28, 56, 70, 56, 28, 8, 1 };

	// Wir brauchen die Summe der 1D-Reihen für die Normalisierung.
	const float sum1D_7 = 64.0f;  // (1+6+15+20+15+6+1)
	const float sum1D_9 = 256.0f; // (1+8+... ...+8+1)

	float g7[7][7]; // 7x7-Maske (kleiner Weichzeichner)
	float g9[9][9]; // 9x9-Maske (großer Weichzeichner)
	// 7x7-Maske berechnen
	for (int u = 0; u < 7; ++u) {
		for (int v = 0; v < 7; ++v) {
			g7[u][v] = (b7[u] * b7[v]) / (sum1D_7 * sum1D_7);
		}
	}
	// 9x9-Maske berechnen (genau das gleiche Prinzip)
	for (int u = 0; u < 9; ++u) {
		for (int v = 0; v < 9; ++v) {
			g9[u][v] = (b9[u] * b9[v]) / (sum1D_9 * sum1D_9);
		}
	}

	//----Zwischenspeicher erstellen
	static float blur7[MAXXDIM][MAXYDIM];
	static float blur9[MAXXDIM][MAXYDIM];

	//Zwischenspeicherpaltz schwarz setzen.
	reset_matrix(out); //Ausgangsbild schwarz machen
	for (int x = 0; x < MAXXDIM; x++) {
		for (int y = 0; y < MAXYDIM; y++) {
			blur7[x][y] = 0;
			blur9[x][y] = 0;
		}
	}

	// Randbereich beachten
	const int m7 = 3; //7x7 Matrix
	const int m9 = 4; //9x9 Matrix = 4, weil man von dem Mittelpunkt vier Pixel in alle richtiungen geht.

	// --- 7x7-Faltung ---
	for (int x = m7; x < MAXXDIM - m7; x++) { // laufen von -3 bis +3
		for (int y = m7; y < MAXYDIM - m7; y++) {
			float result = 0; // Das Ergebniss wird aufsummiert.

			for (int dx = -m7; dx <= m7; dx++) { 
				for (int dy = -m7; dy <= m7; dy++) {
					result += (float)in[x + dx][y + dy] * g7[dx + m7][dy + m7]; //Berechnung gewichteter Durchschnitt
				}
			}
			blur7[x][y] = result;
		}
	}

	// ---  9x9-Faltung ---
	for (int x = m9; x < MAXXDIM - m9; x++) {
		for (int y = m9; y < MAXYDIM - m9; y++) {
			float result = 0;
			for (int dx = -m9; dx <= m9; dx++) { // laufen von -4 bis +4
				for (int dy = -m9; dy <= m9; dy++) {
					result += (float)in[x + dx][y + dy] * g9[dx + m9][dy + m9];
				}
			}
			blur9[x][y] = result;
		}
	}

	//Verwendung m9 Randbereich, da dieser größer ist als der Randbreich m7
	for (int x = m9; x < MAXXDIM - m9; x++) {
		for (int y = m9; y < MAXYDIM - m9; y++) {

			float dif = blur9[x][y] - blur7[x][y];
			//If Abfrage, weil die Differenz Werte von -255 bis +255
			if (dif < 0)
			{
				dif = 0; //Alles unter 0 wird schwarz.
			}
			if (dif > 255)
			{
				dif = 255; //Alles über 255 wird weiß.
			}
			// Der fertige Kanten-Pixel wird ins Endergebnis-Bild geschrieben
			out[x][y] = dif;
		}
	}

}